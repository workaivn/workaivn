import { useState, useRef, useEffect } from "react";

export default function Sidebar({
  chats = [],
  openChat,
  newChat,
  logout,
  tab,
  setTab
}) {
  const [menuId, setMenuId] =
    useState(null);

  const menuRef = useRef(null);

  useEffect(() => {
    function closeMenu(e) {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target)
      ) {
        setMenuId(null);
      }
    }

    document.addEventListener(
      "mousedown",
      closeMenu
    );

    return () =>
      document.removeEventListener(
        "mousedown",
        closeMenu
      );
  }, []);

  function isImageChat(chat) {
    const msgs =
      chat.messages || [];

    return msgs.some(m => {
      const c = String(
        m.content || ""
      ).toLowerCase();

      return (
        c.includes("🖼️") ||
        c.includes("data:image") ||
        c.includes(
          "blob.core.windows.net"
        ) ||
        c.includes(
          "openaiusercontent.com"
        ) ||
        c.includes(
          "images.openai"
        )
      );
    });
  }

  const filteredChats =
    chats.filter(chat =>
      tab === "image"
        ? isImageChat(chat)
        : !isImageChat(chat)
    );

  function cleanTitle(chat) {
    if (
      isImageChat(chat)
    ) {
      return (
        chat.title ||
        "Ảnh AI"
      );
    }

    return (
      chat.title ||
      "New Chat"
    );
  }

  function handleOpen(chat) {
    openChat(chat._id);
  }

  function renameChat(id) {
    const title =
      prompt("Tên mới:");

    if (!title) return;

    fetch(
      "http://localhost:3000/api/chat/" +
        id +
        "/rename",
      {
        method: "PUT",
        headers: {
          "Content-Type":
            "application/json"
        },
        body: JSON.stringify({
          title
        })
      }
    ).then(() =>
      location.reload()
    );
  }

  function deleteChat(id) {
    if (
      !confirm(
        "Xóa chat?"
      )
    )
      return;

    fetch(
      "http://localhost:3000/api/chat/" +
        id,
      {
        method:
          "DELETE"
      }
    ).then(() =>
      location.reload()
    );
  }

  return (
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="logo">
          AI SaaS
        </div>

        <button
          className="newBtn"
          onClick={
            newChat
          }
        >
          + New Chat
        </button>

        <div className="sideTabs">
          <button
            className={
              tab ===
              "chat"
                ? "active"
                : ""
            }
            onClick={() =>
              setTab(
                "chat"
              )
            }
          >
            Chat
          </button>

          <button
            className={
              tab ===
              "image"
                ? "active"
                : ""
            }
            onClick={() =>
              setTab(
                "image"
              )
            }
          >
            Ảnh
          </button>
        </div>
      </div>

      <div className="sidebar-body">
        <div className="recentTitle">
          Recents
        </div>

        <div className="history">
          {filteredChats.map(
            chat => (
              <div
                key={
                  chat._id
                }
                className="chatRow"
              >
                <div
                  className="chatTitle"
                  onClick={() =>
                    handleOpen(
                      chat
                    )
                  }
                >
                  {cleanTitle(
                    chat
                  )}
                </div>

                <button
                  className="moreBtn"
                  onClick={() =>
                    setMenuId(
                      menuId ===
                        chat._id
                        ? null
                        : chat._id
                    )
                  }
                >
                  ...
                </button>

                {menuId ===
                  chat._id && (
                  <div
                    className="menuBox"
                    ref={
                      menuRef
                    }
                  >
                    <button
                      onClick={() => {
                        renameChat(
                          chat._id
                        );
                        setMenuId(
                          null
                        );
                      }}
                    >
                      ✏️ Rename
                    </button>

                    <button
                      onClick={() => {
                        deleteChat(
                          chat._id
                        );
                        setMenuId(
                          null
                        );
                      }}
                    >
                      🗑 Delete
                    </button>
                  </div>
                )}
              </div>
            )
          )}
        </div>
      </div>

      <div className="sidebar-footer">
        <button
          className="logoutBtn"
          onClick={
            logout
          }
        >
          Logout
        </button>
      </div>
    </aside>
  );
}