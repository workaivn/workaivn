// src/components/MessageList.jsx
import ReactMarkdown from "react-markdown";
import { useState } from "react";

function CodeBlock({
  inline,
  className,
  children
}) {
  const code = String(children);
  const [copied, setCopied] =
    useState(false);

  if (inline)
    return <code>{code}</code>;

  async function copy() {
    await navigator.clipboard.writeText(
      code
    );
    setCopied(true);
    setTimeout(
      () =>
        setCopied(false),
      1200
    );
  }

  return (
    <div className="codeWrap">
      <div className="codeTop">
        <span>
          {className?.replace(
            "language-",
            ""
          ) || "code"}
        </span>

        <button
          className="codeBtn"
          onClick={copy}
        >
          {copied
            ? "Copied"
            : "Copy"}
        </button>
      </div>

      <pre>
        <code>{code}</code>
      </pre>
    </div>
  );
}

function LinkRenderer({
  href,
  children
}) {
  const isFile =
    href?.includes(
      "/files/"
    );

  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className={
        isFile
          ? "fileLink"
          : "link"
      }
    >
      {isFile
        ? "⬇ Download file"
        : children}
    </a>
  );
}

export default function MessageList({
  messages = [],
  loading = false
}) {
  return (
    <section className="chatArea">

      {messages.map(
        (
          msg,
          index
        ) => {
          const content =
            msg.content ||
            "";

          const isImg =
            content.startsWith(
              "data:image"
            );

          const isFile =
            content.startsWith(
              '{"type":"file"'
            );

          let file = null;

          try {
            if (isFile)
              file =
                JSON.parse(
                  content
                );
          } catch {}

          return (
            <div
              key={index}
              className={`row ${msg.role}`}
            >
              <div
                className={`bubble ${msg.role}`}
              >

                {isImg ? (
                  <img
                    src={
                      content
                    }
                    className="chatImg"
                  />
                ) : file ? (
                  <div className="fileCard">
                    📄{" "}
                    {
                      file.name
                    }
                  </div>
                ) : (
                  <ReactMarkdown
                    components={{
                      code: CodeBlock,
                      a: LinkRenderer
                    }}
                  >
                    {
                      content
                    }
                  </ReactMarkdown>
                )}

              </div>
            </div>
          );
        }
      )}

      {loading && (
        <div className="row assistant">
          <div className="bubble assistant">
            ● ● ●
          </div>
        </div>
      )}

    </section>
  );
}