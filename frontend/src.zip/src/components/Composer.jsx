import { useEffect, useRef, useState } from "react";

export default function Composer({
  text,
  setText,
  send,
  search,
  setSearch,
  loading
}) {
  const fileRef = useRef(null);
  const textareaRef = useRef(null);

  const [preview, setPreview] =
    useState(null);

  const [dragging, setDragging] =
    useState(false);

  /* AUTO FOCUS */
  useEffect(() => {
    if (!loading) {
      textareaRef.current?.focus();
    }
  }, [loading]);

  async function submit() {
    if (loading) return;

    const ok =
      await send(preview);

    if (ok) {
      setPreview(null);

      if (fileRef.current) {
        fileRef.current.value =
          "";
      }

      if (textareaRef.current) {
        textareaRef.current.style.height =
          "44px";

        textareaRef.current.focus();
      }
    }
  }

  function autoResize(el) {
    el.style.height = "44px";

    const h =
      Math.min(
        el.scrollHeight,
        220
      );

    el.style.height =
      h + "px";
  }

  function onKeyDown(e) {
    if (
      e.key === "Enter" &&
      !e.shiftKey
    ) {
      e.preventDefault();

      if (
        text.trim() ||
        preview
      ) {
        submit();
      }
    }
  }

  function handleFile(file) {
    if (!file) return;

    /* IMAGE */
    if (
      file.type.startsWith(
        "image/"
      )
    ) {
      const reader =
        new FileReader();

      reader.onload = () =>
        setPreview({
          type: "image",
          file,
          name:
            file.name,
          data:
            reader.result
        });

      reader.readAsDataURL(
        file
      );

      return;
    }

    /* OTHER FILE */
    setPreview({
      type: "file",
      file,
      name: file.name,
      size: file.size
    });
  }

  function onChangeFile(e) {
    handleFile(
      e.target.files?.[0]
    );
  }

  function removePreview() {
    setPreview(null);

    if (fileRef.current) {
      fileRef.current.value =
        "";
    }

    textareaRef.current?.focus();
  }

  function onDrop(e) {
    e.preventDefault();
    e.stopPropagation();

    setDragging(false);

    const file =
      e.dataTransfer.files?.[0];

    if (file) {
      handleFile(file);
    }
  }

  function onPaste(e) {
    const items =
      e.clipboardData.items;

    for (const item of items) {
      if (
        item.type.startsWith(
          "image/"
        )
      ) {
        handleFile(
          item.getAsFile()
        );
        break;
      }
    }
  }

  return (
    <div
      className={`composerWrap ${
        dragging
          ? "dragging"
          : ""
      }`}
      onDragEnter={e => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragOver={e => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={e => {
        e.preventDefault();

        if (
          e.currentTarget ===
          e.target
        ) {
          setDragging(false);
        }
      }}
      onDrop={onDrop}
    >
      <div className="composer">
        {/* FILE */}
        <button
          type="button"
          className="iconBtn"
          disabled={loading}
          onClick={() =>
            fileRef.current?.click()
          }
          title="Đính kèm file"
        >
          📎
        </button>

        <input
          hidden
          ref={fileRef}
          type="file"
          onChange={
            onChangeFile
          }
        />

        {/* SEARCH */}
        <button
          type="button"
          className={`iconBtn ${
            search
              ? "active"
              : ""
          }`}
          disabled={loading}
          onClick={() =>
            setSearch(
              !search
            )
          }
          title="Tìm web"
        >
          🌐
        </button>

        {/* INPUT */}
        <div className="inputArea">
          {/* IMAGE */}
          {preview?.type ===
            "image" && (
            <div className="uploadPreview">
              <img
                src={
                  preview.data
                }
                alt=""
              />

              {!loading && (
                <button
                  type="button"
                  className="removePreview"
                  onClick={
                    removePreview
                  }
                >
                  ✕
                </button>
              )}
            </div>
          )}

          {/* FILE */}
          {preview?.type ===
            "file" && (
            <div className="filePreview">
              📄{" "}
              {preview.name}

              {!loading && (
                <button
                  type="button"
                  className="removePreview"
                  onClick={
                    removePreview
                  }
                >
                  ✕
                </button>
              )}
            </div>
          )}

          <textarea
            ref={textareaRef}
            rows="1"
            value={text}
            disabled={loading}
            placeholder="Nhắn AI..."
            onChange={e => {
              setText(
                e.target.value
              );
              autoResize(
                e.target
              );
            }}
            onKeyDown={
              onKeyDown
            }
            onPaste={onPaste}
          />
        </div>

        {/* SEND */}
        <button
          type="button"
          className="sendBtn"
          disabled={
            loading ||
            (!text.trim() &&
              !preview)
          }
          onClick={submit}
          title="Gửi"
        >
          {loading
            ? "..."
            : "➜"}
        </button>
      </div>
    </div>
  );
}