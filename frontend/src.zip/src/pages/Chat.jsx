import { useEffect, useRef, useState } from "react";
import Sidebar from "../components/Sidebar";
import Composer from "../components/Composer";
import MessageList from "../components/MessageList";
import { apiGet, apiPost } from "../services/api";

export default function Chat({ tab, setTab }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState(false);
  const [chats, setChats] = useState([]);
  const [chatId, setChatId] = useState(null);

  const chatIdRef = useRef(null);
  const endRef = useRef(null);

  useEffect(() => {
    loadChats();
  }, []);

  useEffect(() => {
    const id =
      localStorage.getItem(
        "openChatId"
      );

    if (id) {
      openChat(id);
      localStorage.removeItem(
        "openChatId"
      );
    }
  }, []);

  useEffect(() => {
    chatIdRef.current = chatId;
  }, [chatId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  }, [messages]);

  async function loadChats() {
    try {
      const r =
        await apiGet("/chats");
      const d =
        await r.json();

      setChats(
        Array.isArray(d)
          ? d
          : []
      );
    } catch {
      setChats([]);
    }
  }

  async function openChat(id) {
    try {
      const r =
        await apiGet(
          "/chat/" + id
        );

      const d =
        await r.json();

      setChatId(id);
      chatIdRef.current = id;
      setMessages(
        d.messages || []
      );
    } catch (err) {
      console.log(err);
    }
  }

  function newChat() {
    setMessages([]);
    setText("");
    setChatId(null);
    chatIdRef.current =
      null;
  }

  function logout() {
    localStorage.removeItem(
      "token"
    );
    location.reload();
  }

  async function refreshAfterSend(
    newId = null
  ) {
    if (newId) {
      setChatId(newId);
      chatIdRef.current =
        newId;

      await openChat(newId);
    }

    await loadChats();
  }

  async function generateFile(
    type,
    prompt
  ) {
    setMessages(prev => [
      ...prev,
      {
        role: "user",
        content: prompt
      }
    ]);

    setLoading(true);

    try {
      const r =
        await fetch(
          `http://localhost:3000/api/generate-${type}`,
          {
            method: "POST",
            headers: {
              "Content-Type":
                "application/json",
              authorization:
                localStorage.getItem(
                  "token"
                )
            },
            body: JSON.stringify({
              content:
                prompt,
              chatId:
                chatIdRef.current
            })
          }
        );

      const d =
        await r.json();

      await refreshAfterSend(
        d.chatId
      );
    } catch {
      setMessages(prev => [
        ...prev,
        {
          role:
            "assistant",
          content:
            "Lỗi tạo file."
        }
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function uploadRealFile(
    fileObj,
    prompt
  ) {
    setMessages(prev => [
      ...prev,
      {
        role: "user",
        content:
          prompt?.trim()
            ? `📎 ${fileObj.name}\n\n${prompt}`
            : `📎 ${fileObj.name}`
      }
    ]);

    setLoading(true);

    try {
      const form =
        new FormData();

      form.append(
        "file",
        fileObj.file
      );

      form.append(
        "chatId",
        chatIdRef.current ||
          ""
      );

      form.append(
        "prompt",
        prompt || ""
      );

      const r =
        await fetch(
          "http://localhost:3000/api/upload-file",
          {
            method:
              "POST",
            headers: {
              authorization:
                localStorage.getItem(
                  "token"
                )
            },
            body: form
          }
        );

      const d =
        await r.json();

      await refreshAfterSend(
        d.chatId
      );
    } catch {
      setMessages(prev => [
        ...prev,
        {
          role:
            "assistant",
          content:
            "Lỗi upload file."
        }
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function sendText(
    prompt
  ) {
    const next = [
      ...messages,
      {
        role: "user",
        content: prompt
      }
    ];

    setMessages(next);
    setLoading(true);

    try {
      const r =
        await apiPost(
          "/chat",
          {
            messages: next,
            search,
            chatId:
              chatIdRef.current
          }
        );

      if (!r.body) {
        throw new Error(
          "No stream"
        );
      }

      const reader =
        r.body.getReader();

      const decoder =
        new TextDecoder();

      let ai = "";

      while (true) {
        const {
          done,
          value
        } =
          await reader.read();

        if (done) break;

        ai +=
          decoder.decode(
            value,
            {
              stream: true
            }
          );

        setMessages(
          prev => {
            const copy =
              [...prev];

            if (
              copy.at(-1)
                ?.role ===
              "assistant"
            ) {
              copy[
                copy.length -
                  1
              ] = {
                role:
                  "assistant",
                content:
                  ai
              };
            } else {
              copy.push({
                role:
                  "assistant",
                content:
                  ai
              });
            }

            return copy;
          }
        );
      }

      /* IMPORTANT */
      await loadChats();

      if (
        !chatIdRef.current &&
        chats.length > 0
      ) {
        await loadChats();
      }
    } catch {
      setMessages(prev => [
        ...prev,
        {
          role:
            "assistant",
          content:
            "Lỗi phản hồi AI."
        }
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function send(
    fileObj = null
  ) {
    const prompt =
      text.trim();

    if (
      !prompt &&
      !fileObj
    )
      return false;

    if (loading)
      return false;

    setText("");

    const lower =
      prompt.toLowerCase();

    try {
      if (
        fileObj?.type ===
        "file"
      ) {
        await uploadRealFile(
          fileObj,
          prompt
        );
        return true;
      }

      if (
        lower.includes(
          "pdf"
        )
      ) {
        await generateFile(
          "pdf",
          prompt
        );
        return true;
      }

      if (
        lower.includes(
          "word"
        ) ||
        lower.includes(
          "docx"
        )
      ) {
        await generateFile(
          "word",
          prompt
        );
        return true;
      }

      if (
        lower.includes(
          "excel"
        ) ||
        lower.includes(
          "xlsx"
        )
      ) {
        await generateFile(
          "excel",
          prompt
        );
        return true;
      }

      if (
        lower.includes(
          "zip"
        )
      ) {
        await generateFile(
          "zip",
          prompt
        );
        return true;
      }

      await sendText(prompt);
      return true;
    } catch {
      return false;
    }
  }

  return (
    <div className="app">
      <Sidebar
        chats={chats}
        openChat={openChat}
        newChat={newChat}
        logout={logout}
        tab={tab}
        setTab={setTab}
      />

      <main className="main">
        <header className="topbar">
          White Pro Max
        </header>

        <MessageList
          messages={
            messages
          }
          loading={
            loading
          }
        />

        <div ref={endRef}></div>

        <Composer
          text={text}
          setText={setText}
          send={send}
          search={search}
          setSearch={
            setSearch
          }
          loading={
            loading
          }
        />
      </main>
    </div>
  );
}