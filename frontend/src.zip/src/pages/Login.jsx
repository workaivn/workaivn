import {useState} from 'react';
const API='http://localhost:3000/api';
export default function Login({setPage}){
 const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState('');
 async function login(){const r=await fetch(API+'/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})}); const d=await r.json(); if(d.token){localStorage.setItem('token',d.token); location.reload();} else setError('Sai tài khoản hoặc mật khẩu');}
 return <div className='authWrap'><div className='authBox'><h1>AI SaaS</h1><p>Đăng nhập để tiếp tục</p><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)}/><input type='password' placeholder='Mật khẩu' value={password} onChange={e=>setPassword(e.target.value)}/>{error&&<div className='errorBox'>{error}</div>}<button onClick={login}>Đăng nhập</button><span onClick={()=>setPage('register')}>Chưa có tài khoản? Tạo ngay</span></div></div>
}