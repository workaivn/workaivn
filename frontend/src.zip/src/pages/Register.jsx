import {useState} from 'react';
const API='http://localhost:3000/api';
export default function Register({setPage}){
 const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [repassword,setRepassword]=useState(''); const [error,setError]=useState('');
 async function register(){if(password!==repassword) return setError('Mật khẩu không khớp'); const r=await fetch(API+'/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})}); const d=await r.json(); if(d.ok){setPage('login')} else setError('Email đã tồn tại');}
 return <div className='authWrap'><div className='authBox'><h1>Tạo tài khoản</h1><p>Gia nhập White Pro Max</p><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)}/><input type='password' placeholder='Mật khẩu' value={password} onChange={e=>setPassword(e.target.value)}/><input type='password' placeholder='Nhập lại mật khẩu' value={repassword} onChange={e=>setRepassword(e.target.value)}/>{error&&<div className='errorBox'>{error}</div>}<button onClick={register}>Tạo tài khoản</button><span onClick={()=>setPage('login')}>Đã có tài khoản? Đăng nhập</span></div></div>
}