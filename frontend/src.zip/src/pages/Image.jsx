import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { apiGet } from "../services/api";

export default function ImagePage({
  tab,
  setTab
}) {
  const [prompt, setPrompt] =
    useState("");

  const [img, setImg] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [chats, setChats] =
    useState([]);

  const [chatId, setChatId] =
    useState(null);

  useEffect(() => {
    loadChats();
  }, []);

  async function loadChats() {
    try {
      const r =
        await apiGet("/chats");

      const d =
        await r.json();

      setChats(
        Array.isArray(d)
          ? d
          : []
      );
    } catch {
      setChats([]);
    }
  }

  async function openChat(id) {
    try {
      const r =
        await apiGet(
          "/chat/" + id
        );

      const d =
        await r.json();

      setChatId(id);

      const msgs =
        d.messages || [];

      let found = "";

      for (const m of msgs) {
        const c = String(
          m.content || ""
        );

        /* base64 image */
        if (
          c.includes(
            "data:image"
          )
        ) {
          const i =
            c.indexOf(
              "data:image"
            );

          found =
            c.slice(i).trim();
        }

        /* image url */
        else if (
          c.includes(
            "http"
          )
        ) {
          const arr =
            c.split(/\s+/);

          const url =
            arr.find(
              x =>
                x.startsWith(
                  "http"
                )
            );

          if (url)
            found =
              url.trim();
        }
      }

      setImg(found);
    } catch {
      setImg("");
    }
  }

  async function generate() {
    if (!prompt.trim())
      return;

    setLoading(true);

    try {
      const r = await fetch(
        "http://localhost:3000/api/generate-image",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
            authorization:
              localStorage.getItem(
                "token"
              )
          },
          body: JSON.stringify({
            prompt,
            chatId
          })
        }
      );

      const d =
        await r.json();

      if (!r.ok) {
        throw new Error(
          d.error ||
            "Tạo ảnh lỗi"
        );
      }

      setImg(
        d.imageUrl || ""
      );

      setChatId(
        d.chatId
      );

      await loadChats();
    } catch (err) {
      alert(
        err.message ||
          "Tạo ảnh lỗi"
      );
    }

    setLoading(false);
  }

  function newChat() {
    setChatId(null);
    setImg("");
    setPrompt("");
  }

  function logout() {
    localStorage.removeItem(
      "token"
    );

    location.reload();
  }

  return (
    <div className="app">
      <Sidebar
        chats={chats}
        openChat={openChat}
        newChat={newChat}
        logout={logout}
        tab={tab}
        setTab={setTab}
      />

      <main className="main">
        <header className="topbar">
          Tạo ảnh AI
        </header>

        <div className="imagePage">
          <textarea
            placeholder="Mô tả ảnh cần tạo..."
            value={prompt}
            onChange={e =>
              setPrompt(
                e.target.value
              )
            }
          />

          <button
            onClick={
              generate
            }
          >
            {loading
              ? "Đang tạo..."
              : "Tạo ảnh"}
          </button>

          {img && (
            <img
              src={img}
              className="resultImg"
              alt="AI"
            />
          )}
        </div>
      </main>
    </div>
  );
}