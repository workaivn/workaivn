const API='http://localhost:3000/api';
export const getToken=()=>localStorage.getItem('token')||'';
export async function apiGet(url){return fetch(API+url,{headers:{authorization:getToken()}})}
export async function apiPost(url,body){return fetch(API+url,{method:'POST',headers:{'Content-Type':'application/json',authorization:getToken()},body:JSON.stringify(body)})}