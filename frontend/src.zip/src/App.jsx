import { useState } from "react";

import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Chat from "./pages/Chat.jsx";
import ImagePage from "./pages/Image.jsx";

export default function App() {
  const token = localStorage.getItem("token");

  const [page, setPage] = useState(
    token ? "home" : "login"
  );

  const [tab, setTab] = useState("chat");

  if (page === "login") {
    return <Login setPage={setPage} />;
  }

  if (page === "register") {
    return <Register setPage={setPage} />;
  }

  return (
    <>
      {tab === "chat" && (
        <Chat
          tab={tab}
          setTab={setTab}
        />
      )}

      {tab === "image" && (
        <ImagePage
          tab={tab}
          setTab={setTab}
        />
      )}
    </>
  );
}